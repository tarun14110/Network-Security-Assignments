DESCRIPTION
When Client registers, it creates a private key and Certificate signing request (CSR). And sends CSR to CA server. CA signs the certificate for the client and sends its to the client. (Instead od sending CSR and receiving certificate, I am using a common directory for this purpose). Whenever User A wants to communicate to B. It sends a request to server, server than decides common available port for both, and notifies both of them. A will act as a client, and asks for B certificate. B also asks for A's certificate for mutual authentication. Then they both verifies the certificate. If succesfull, connection setups and message transfer using TLS connection.

CORNER CASES
Displays to all users whenever a user goes offline.
Display message when tries to msg unregister or offline user.
If the message format is wrong display error.
Entered message should not be null
Set 100 character limit for message.
Opening different ports of user A, in case multiple users wants to communicate to A.








