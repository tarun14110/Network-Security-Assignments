
/*
* PeerChat - a simple linux commandline Client - client chat
* Author: Tarun kumar yadav
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>

#include "chatroom_utils.h"
#include "encrypt.h"

#define FILE_SIZE 1000000000

char encryptUsernames[10][50];
char encryptKey[10][8192];
char userPassword[50];

// get a username from the user.
void get_username(char *username)
{
  while(true)
  {
    printf("Enter username and password separated by space <username password>: ");
    fflush(stdout);
    memset(username, 0, 1000);
    fgets(username, 22, stdin);
    trim_newline(username);

    if(strlen(username) > 20)
    {
      puts("Username must be 20 characters or less.");
    } else {
      break;
    }
  }
}

void login_success(connection_info *connection, char *data) {
  //printf("LOGINN CHECK\n");
    if (strcmp(data,"0")==0) {
        printf("Wrong credentials \n"); 
        exit(1);     
    }
    
          char tem[100];
        strcpy(tem, connection->username);
        //puts(tem);
        strtok(tem, " ");
        strcpy(userPassword, strtok(NULL, ""));
        //puts("TIKLU");
    //puts(userPassword);


  printf("Login successfull\n");
}

//send local username to the server.
void set_username(connection_info *connection)
{
  message msg;
  msg.type = SET_USERNAME;
  strncpy(msg.username, connection->username, 20);

  if(send(connection->socket, (void*)&msg, sizeof(msg), 0) < 0)
  {
    perror("Send failed");
    exit(1);
  }
}

void stop_client(connection_info *connection)
{
  close(connection->socket);
  exit(0);
}

//initialize connection to the server.
void connect_to_server(connection_info *connection, char *address, char *port)
{

  while(true)
  {
    get_username(connection->username);

    //Create socket
    if ((connection->socket = socket(AF_INET, SOCK_STREAM , IPPROTO_TCP)) < 0)
    {
        perror("Could not create socket");
    }

    connection->address.sin_addr.s_addr = inet_addr(address);
    connection->address.sin_family = AF_INET;
    connection->address.sin_port = htons(atoi(port));

    //Connect to remote server
    if (connect(connection->socket, (struct sockaddr *)&connection->address , sizeof(connection->address)) < 0)
    {
        perror("Connect failed.");
        exit(1);
    }

    set_username(connection);
    break;
  }


  puts("Connected to server.");
  puts("Type /help for usage.");
}


void handle_user_input(connection_info *connection)
{

  char input[255];
  fgets(input, 255, stdin);
  trim_newline(input);


  if(strcmp(input, "/q") == 0 || strcmp(input, "/quit") == 0)
  {
    stop_client(connection);
  }
  else if(strcmp(input, "/who") == 0)
  {
    message msg;
    msg.type = GET_USERS;

    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }
  }
  else if(strcmp(input, "/help") == 0)
  {
    puts("/quit or /q: Exit the program.");
    puts("/help: Displays help information.");
    puts("/who: Displays list of users in chatroom.");
    puts("/msg <username> <message> Send a private message to given username.");
    puts("/create_grp <groupname> <members_separated_with_spaces> Create a new group with following members");
    puts("/join_grp <groupname> Join existing group.");
    puts("/send <username> <filename> Sends file to the user");
    puts("/msg_group <groupname> <messgae> Broadcasts message to the whole group");
    puts("/recv Join Receive all files you received and you didn't downloaded.");
  } else if (strncmp(input, "/msg_group", 10) == 0)
  { 
    message msg;
    msg.type = PUBLIC_MESSAGE;
    

    char *groupName;

    groupName = strtok(input+10, " ");

    if(strlen(groupName) > 20)
    {
      puts(KRED "The groupName must be between 1 and 20 characters." RESET);
      return;
    }

    if(groupName == NULL)
    {
      puts(KRED "You must enter a groupName." RESET);
      return;
    }

    // clear_stdin_buffer();

/*    if(strlen(input) == 0) {
        return;
    }
*/
    strncpy(msg.username, groupName, 20);
    strncpy(msg.data, strtok(NULL, ""), 255);

    //Send some data
    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }
  } else if(strncmp(input, "/msg", 4) == 0)
  {

//puts(input);


char receiver[50];
char data[100];
char masterKey[8192];

strcpy(receiver, strtok(input+5, " "));
strcpy(data, strtok(NULL, ""));
/*puts("dada");
puts(receiver);
puts(data);
puts("dada");*/
    int i =0;
    int keyIndex = -1;
    for (i = 0; i < 10; ++i) {
      if (strcmp(receiver, encryptUsernames[i]) == 0) {
        keyIndex = i;
        strcpy(masterKey, encryptKey[i]);
        break;
      }
    }

/*puts("first");
puts(input);*/

     //connection_info connectionKDP;
    fd_set file_descriptors;

    int sock;
    struct sockaddr_in server;
    char server_reply[2000];
    //puts("eee ");
    



if (keyIndex == -1) {


     puts("Communicating with KDC for master key");
    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }
    //puts("Socket created");
     
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(9999);
 
    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
    }
     
    //puts("talking to KDC\n");





 /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  // puts("KAAL");
  unsigned char ciphertext[8192];
  //puts("AAJ");

  /* Buffer for the decrypted text */
  unsigned char decryptedtext[8192];

  int decryptedtext_len, ciphertext_len;


//puts("IISSS");

  //printf("Send message");
        /*message msg;*/
/*        fgets(msg.username, 100, stdin);
        printf ("looo");
        fgets(msg.data, 100, stdin);
        printf ("pooo");*/

/*        strcpy(msg.username,"broo");
        strcpy(msg.data, "mml");*/

        char username[50];
        strcpy(username, strtok(connection->username," "));
        char password[50];
        strcpy(password, userPassword);
//puts("HIHA");
        char KDCmessage[50];
        strcpy(KDCmessage, "500");
       // puts("LILA");
        strcat(KDCmessage, " ");
        strcat(KDCmessage, username);
       // puts("JIJA");
        strcat(KDCmessage, " ");
        strcat(KDCmessage, strtok(receiver, " "));
        

        if( send(sock , KDCmessage , strlen(KDCmessage) , 0) < 0)
        {
            puts("Send failed");
        }
//puts ("jooo");
  /*  memset(server_reply, 0, sizeof server_reply);*/
  //  printf ("yooo");
    if( recv(sock , ciphertext , 8192 , 0) < 0)
        {
            puts("recv failed");
        }
    //printf("%s", server_reply); 
    //puts("mmm");
    //puts(ciphertext);



char modifiedMsg[8192];
char data[8192];

strcpy(data, strtok(ciphertext, " "));
//strcpy(length, atoi(strtok(NULL, " ")));

int p, commaCount=0;
for (p = 0; p < strlen(data); ++p) {
  if (data[p] == ',') {
    ++commaCount;
  }
}
int length=commaCount;
//puts("YEE");
//puts(data);
//puts("PP");
//printf("%d\n", length);


    char *pt;
    pt = strtok (data,",");
   // puts("LLLL");
    strcpy(modifiedMsg, "");
    i = 0;
    while (pt != NULL) {
      //puts("FF");
        int a = atoi(pt);
        //puts("II");
        modifiedMsg[i] = (char)a;
       // puts(pt);
        //puts("GG");
        pt = strtok (NULL, ",");
        //puts("HH");
/*        if (strcmp(pt,"")==0)
          break;*/
        ++i;
        if (commaCount == i)
          break;
    }

/*puts("OOKKO");
puts(modifiedMsg);*/








  /* Set up the key and iv. Do I need to say to not hard code these in a
   * real application? :-)
   */

  /* A 256 bit key */
  unsigned char *key = (unsigned char *)password;

  /* A 8192 bit IV */
  unsigned char *iv = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  /*unsigned char *plaintext =
                (unsigned char *)"The quick brown fox jumps over the lazy dog";

 */

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext_len = strlen((const char*)ciphertext);

  /* Do something useful with the ciphertext here */
 // printf("Ciphertext is:\n");
  //puts(modifiedMsg);
  //BIO_dump_fp (stdout, (const char *)modifiedMsg, length);

  //BIO_dump_fp (stdout, (const char *)ciphertext, 2048);

  //puts(key);
  //puts(password);
  /* Decrypt the ciphertext */
  decryptedtext_len = decrypt((unsigned char *)modifiedMsg, length, key, iv,
    decryptedtext);
//puts("munna");
  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext[decryptedtext_len] = '\0';
//puts("jajaj");
  /* Show the decrypted text */
  //printf("Decrypted text is:\n");
  //printf("%s\n", decryptedtext);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();


char contactPerson[50];
char timeStamp[50];
char dataToSendToOther[8192];

//puts("JUJU");
strcpy(masterKey, strtok(decryptedtext, " "));
//puts(masterKey);
strcpy(contactPerson, strtok(NULL, " "));
//puts(contactPerson);
strcpy(timeStamp, strtok(NULL, " "));
strcpy(dataToSendToOther, strtok(NULL, ""));
//puts(dataToSendToOther);

    message msg;
    msg.type = PRIVATE_MESSAGE;
   // puts(msg.type=20);
    strncpy(msg.username, receiver, 20);
    char tem[8192];
    strncpy(tem, dataToSendToOther, 8192);
    strcpy(msg.data, "KDC3 ");
    strcat(msg.data, tem);

    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }
    fflush(stdout);
//puts("MERE");
message mmsg;
   int c = 1, d = 1;

if (recv(connection->socket, &mmsg , sizeof(mmsg) , 0) <0) {
  puts("recv failed");
}
//puts("BRo");
//puts(mmsg.data);
 /* A 256 bit key */
  unsigned char *key5 = (unsigned char *)masterKey;

  /* A 8192 bit IV */
  unsigned char *iv5 = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext5 =
                (unsigned char *)"The quick brown fox jumps over the lazy dog";

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext5[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext5[8192];

  int decryptedtext5_len, ciphertext5_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext5_len = strlen(mmsg.data);

  /* Do something useful with the ciphertext here */
 /* printf("Ciphertext is:\n");
  BIO_dump_fp (stdout, (const char *)ciphertext, ciphertext_len);
*/
  /* Decrypt the ciphertext */
  decryptedtext5_len = decrypt(mmsg.data, ciphertext5_len, key5, iv5,
    decryptedtext5);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext5[decryptedtext5_len] = '\0';

  /* Show the decrypted text */
  //printf("LAST Decrypted text is:\n");
  //printf("%s\n", decryptedtext5);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();





char updateNonce[10];
snprintf (updateNonce, sizeof(updateNonce), "%d",atoi(decryptedtext5) + 1);

 /* A 256 bit key */
  unsigned char *key6 = (unsigned char *)masterKey;

  /* A 8192 bit IV */
  unsigned char *iv6 = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext6 =
                (unsigned char *)updateNonce;

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext6[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext6[8192];

  int decryptedtext6_len, ciphertext6_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext6_len = encrypt (updateNonce, strlen ((char *)updateNonce), key6, iv6,
                            ciphertext6);

  /* Do something useful with the ciphertext here */
  //printf("Ciphertext is:\n");
  //BIO_dump_fp (stdout, (const char *)ciphertext6, ciphertext6_len);

  /* Decrypt the ciphertext */
  decryptedtext6_len = decrypt(ciphertext6, ciphertext6_len, key6, iv6,
    decryptedtext6);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext6[decryptedtext6_len] = '\0';

  /* Show the decrypted text */
  //printf("Decrypted text is:\n");
  //printf("%s\n", decryptedtext6);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();









   message msgFinal;
    msgFinal.type = PRIVATE_MESSAGE;
    strncpy(msgFinal.username, receiver, 20);
   // puts(msg.type=20);
    strcpy(msgFinal.data, ciphertext6);

    //itoa(atoi(decryptedtext5) + 1, msg.data, 10);
    //snprintf (msg.data, sizeof(msg.data), "%d",atoi(decryptedtext5) + 1);
    //strcpy(msg.data, itoa(atoi(decryptedtext5) + 1));
    /*puts("KIKAKIKA");
    puts(msgFinal.data);*/

    if(send(connection->socket, &msgFinal, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }


 close(sock);

int i;
for (i =0; i < 10; ++i) {
  if (strcmp(encryptUsernames[i],"")==0) {
    strcpy(encryptUsernames[i], receiver);
    strcpy(encryptKey[i], masterKey);
  }
}

}















   

/**Message sending code 

*/
//puts("KAKAKA");

    message msg;
    msg.type = PRIVATE_MESSAGE;
    
    char toUsername[50], chatMsg[100];

    //puts(data);
    strcpy(toUsername,receiver);
//puts("RAJA");
    if(toUsername == NULL)
    {
      puts(KRED "The format for private messages is: /msg <username> <message>" RESET);
      return;
    }

    if(strlen(toUsername) == 0)
    {
      puts(KRED "You must enter a username for a private message." RESET);
      return;
    }

    if(strlen(toUsername) > 20)
    {
      puts(KRED "The username must be between 1 and 20 characters." RESET);
      return;
    }

//puts("MML");
    strcpy(chatMsg, data);

    if(chatMsg == NULL)
    {
      puts(KRED "You must enter a message to send to the specified user." RESET);
      return;
    }




     /* A 256 bit key */
  unsigned char *key7 = (unsigned char *)masterKey;

//puts("MASTER KEY");
//puts(masterKey);
  /* A 8192 bit IV */
  unsigned char *iv7 = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext7 =
                (unsigned char *)chatMsg;

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext7[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext7[8192];

  int decryptedtext7_len, ciphertext7_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext7_len = encrypt (plaintext7, strlen ((char *)plaintext7), key7, iv7,
                            ciphertext7);

  /* Do something useful with the ciphertext here */
 // printf("Ciphertext is:\n");
  //BIO_dump_fp (stdout, (const char *)ciphertext7, ciphertext7_len);

  /* Decrypt the ciphertext */
  decryptedtext7_len = decrypt(ciphertext7, ciphertext7_len, key7, iv7,
    decryptedtext7);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext7[decryptedtext7_len] = '\0';

  /* Show the decrypted text */
  /*printf("LENGTHHHH %d\n", ciphertext7_len);
  printf("Decrypted text is:\n");
  printf("%s\n", decryptedtext7);
*/
  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();


//puts(ciphertext7);
char modifiedCiphertext7[8192];

strcpy(modifiedCiphertext7,"");
char tek[10];
for (i = 0; i < strlen(ciphertext7); ++i) {
    snprintf(tek, 10,"%d",(int)ciphertext7[i]);
    strcat(modifiedCiphertext7, tek);
    strcat(modifiedCiphertext7, ",");
    
}

//printf("%s\n", modifiedCiphertext7);
    strncpy(msg.username, toUsername, 20);
    strncpy(msg.data, modifiedCiphertext7, 8192);



    if(send(connection->socket, &msg, sizeof(msg), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }

  } else if (strncmp(input, "/send", 5) == 0) {              // create grp

    message msg;
    msg.type = SEND_FILE;
    char *username, *filename;

    username = strtok(input+6, " ");
    filename = strtok(NULL, "");


    if(username == NULL || filename == NULL || strlen(username) == 0 || strlen(filename) == 0)
    {
      puts(KRED "The format for send file is: /send <username> <filename>" RESET);
      return;
    }

    if (strlen(username) > 20) {
      puts(KRED "Username exceeds the length." RESET);
      return; 
    }

      if( access( filename, F_OK ) != -1 ) {
    
    char temp[30];
    strcpy(temp, filename);
    strtok(temp,".");
    char *fileType = strtok(NULL,"");

    //Get Picture Size
    printf("Getting file size.\n");
    FILE *picture;
    picture = fopen(filename, "r");
    long long size;
    fseek(picture, 0, SEEK_END);
    size = ftell(picture);
    fseek(picture, 0, SEEK_SET);

    //Send Picture Size
    printf("Sending file size. Size of file is :%lld\n", size);
    sprintf(msg.data, "%s %lld",fileType, size);
    strncpy(msg.username, username, 20);

    if (size > FILE_SIZE) {
      printf("File size out of limit. File size is limited to: %d and your file size is %lld\n", FILE_SIZE, size);
      return;
    }

    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }
    //Send Picture as Byte Array
    printf("Sending Picture as Byte Array. Please wait.\n");
    char send_buffer[1026];
    while(!feof(picture)) {
    fread(send_buffer, 1, 1026, picture);
    write(connection->socket, send_buffer, 1026);
    bzero(send_buffer, 1026);
  }

      } else {
        printf("File don't exists\n");
      }


  } else if (strncmp(input, "/recv", 5) == 0) {              // join grp

    message msg;
    msg.type = RECEIVE_FILE;

    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }

  } else if (strncmp(input, "/create_grp", 11) == 0) {              // create grp

    message msg;
    msg.type = CREATE_GROUP;
    char *groupName, *groupMembers;

    groupName = strtok(input+12, " ");
    groupMembers = strtok(NULL, "");

    if(groupMembers == NULL)
    {
      puts(KRED "The format for create group is: /create_grp <member1 member2 member 3 .... >" RESET);
      return;
    }

    if(strlen(groupMembers) == 0)
    {
      puts(KRED "You must add at least a member to the group." RESET);
      return;
    }

    if(strlen(groupName) > 20)
    {
      puts(KRED "The groupName must be between 1 and 20 characters." RESET);
      return;
    }

    if(groupName == NULL)
    {
      puts(KRED "You must enter a groupName." RESET);
      return;
    }

    strncpy(msg.username, groupName, 20);
    strncpy(msg.data, groupMembers, 255);

    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }

  } else if (strncmp(input, "/join_grp", 9) == 0) {              // join grp

    message msg;
    msg.type = JOIN_GROUP;
    char *groupName;

    groupName = strtok(input+10, " ");

    if(strlen(groupName) > 20)
    {
      puts(KRED "The groupName must be between 1 and 20 characters." RESET);
      return;
    }

    if(groupName == NULL)
    {
      puts(KRED "You must enter a groupName." RESET);
      return;
    }

    strncpy(msg.username, groupName, 20);

    if(send(connection->socket, &msg, sizeof(message), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }

  } else {
    printf("This system doesn't understand this command. Type /help for help\n");
  }

}

void receive_file(connection_info *connection, char *username, char *message_text)
{



  char *fileType = strtok(message_text, " ");
 size_t size = atoi(strtok(NULL,""));
  printf("Reading Picture Byte Array %d\n", (int)size);
  int arraySize = 1026;
  char p_array[arraySize];
  size_t readSize = 0;
char str[30];


int i;
for (i = 0;; ++i) {
  strcpy(str, username);
  sprintf(str, "%s--%d", str, i);
  strcat(str, ".");
  strcat(str, fileType);
  if( access( str, F_OK ) != -1 ) {
    // file exists
} else {
  break;
}
}

FILE *image;
image = fopen(str, "w");
int c= 0;
while (readSize <= size) {
  ++c;
    ssize_t result = read(connection->socket, p_array, arraySize);
    if (0 >= result)
    {
      if (0 == result)
      {
        fprintf(stderr, "The other end gracefully shut down the connection.\n");

        break;
      }
      else
      {
        if (EINTR == errno)  /* got interrupted, start over */
        {
           continue;
        }

        if (EAGAIN == errno)  /* in case reading from a non-blocking socket: no data available, start over */
        {
           continue;
        }

        /* Something went wrong unrecoverable. */
        perror("read() failed");

        break;
      }
    }
    else
    {
       readSize += result;
       if(0 == fwrite(p_array, 1, result, image)) {

        perror("Error while copying file\n");
       }
    }
}
fclose(image);
}


void kdcStep3(connection_info *connection, char *msg) {

//printf(KCYN " %s" RESET "\n",connection->username);

char myUsername[50];
char myPassword[50];
//puts(msg);



char modifiedMsg[8192];



puts("EEEEE");
int p, commaCount=0;
for (p = 0; p < strlen(msg); ++p) {
  if (msg[p] == ',') {
    ++commaCount;
  }
}


    char *pt;
    pt = strtok (msg,",");
    int i = 0;
    //puts("LLLL");
    while (pt != NULL) {
      //puts("FF");
        int a = atoi(pt);
        //puts("II");
        modifiedMsg[i] = (char)a;
        //puts("GG");
        pt = strtok (NULL, ",");
        //puts("HH");
        ++i;
        if (commaCount == i)
          break;
    }

//puts("OOO");
//puts(modifiedMsg);

  //puts(connection->username);
strcpy(myUsername, strtok(connection->username, " "));
//puts("aao");
strcpy(myPassword, userPassword);
//puts(myPassword);

  /* A 256 bit key */
  unsigned char *key = (unsigned char *)myPassword;

  /* A 8192 bit IV */
  unsigned char *iv = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext =
                (unsigned char *)"The quick brown fox jumps over the lazy dog";

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext[8192];

  int decryptedtext_len, ciphertext_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext_len = strlen(modifiedMsg);

  /* Do something useful with the ciphertext here */
  //printf("Ciphertext is:\n");
  //BIO_dump_fp (stdout, (const char *)ciphertext, ciphertext_len);

  /* Decrypt the ciphertext */

  decryptedtext_len = decrypt(modifiedMsg, commaCount, key, iv,
    decryptedtext);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext[decryptedtext_len] = '\0';

  /* Show the decrypted text */
  //printf("Decrypted text is:\n");
  //printf("%s\n", decryptedtext);


  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();





char masterKey[8192];
char contactPerson[50];
char timeStamp[50];
char dataToSendToOther[8192];

strcpy(masterKey, strtok(decryptedtext, " "));
strcpy(contactPerson, strtok(NULL, " "));
strcpy(timeStamp, strtok(NULL, " "));


//puts(masterKey);

//printf("%d", (unsigned)time(NULL) - atoi(timeStamp));
if(((unsigned)time(NULL) - atoi(timeStamp)) > 3000) {
  puts("THERE MAY BE REPLAY ATTACK GOING ON. SO CLOSING.");
  return;
}



 /* A 256 bit key */
  unsigned char *key5 = (unsigned char *)masterKey;

  /* A 8192 bit IV */
  unsigned char *iv5 = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext5 =
                (unsigned char *)"500";

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext5[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext5[8192];

  int decryptedtext5_len, ciphertext5_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext5_len = encrypt (plaintext5, strlen ((char *)plaintext5), key5, iv5,
                            ciphertext5);

  /* Do something useful with the ciphertext here */
 // printf("Ciphertext is:\n");
  //BIO_dump_fp (stdout, (const char *)ciphertext5, ciphertext5_len);

  /* Decrypt the ciphertext */
  decryptedtext5_len = decrypt(ciphertext5, ciphertext5_len, key5, iv5,
    decryptedtext5);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext5[decryptedtext5_len] = '\0';

  /* Show the decrypted text */
  //printf("Decrypted text is:\n");
  //printf("%s\n", decryptedtext5);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();





 
message mmsg;

strcpy(mmsg.data, ciphertext5);
mmsg.type = PRIVATE_MESSAGE;
strcpy(mmsg.username, contactPerson); 
//while(1) {
if(send(connection->socket, &mmsg, sizeof(mmsg), 0) < 0)
    {
        perror("Send failed");
        exit(1);
    }
//puts("SEND");
//}
//puts("DD");










message finalOne;
if (recv(connection->socket, &finalOne , sizeof(finalOne) , 0) <0) {
  puts("recv failed");
}

//puts("LILA");
//puts(finalOne.data);


 /* A 256 bit key */
  unsigned char *key6 = (unsigned char *)masterKey;

  /* A 8192 bit IV */
  unsigned char *iv6 = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext6 =
                (unsigned char *)"The quick brown fox jumps over the lazy dog";

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext6[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext6[8192];

  int decryptedtext6_len, ciphertext6_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext6_len = strlen(finalOne.data);

  /* Do something useful with the ciphertext here */
  /*printf("Ciphertext is:\n");
  BIO_dump_fp (stdout, (const char *)ciphertext6, ciphertext6_len);
*/
  /* Decrypt the ciphertext */
  decryptedtext6_len = decrypt((unsigned char*)finalOne.data, ciphertext6_len, key6, iv6,
    decryptedtext6);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext6[decryptedtext6_len] = '\0';

  /* Show the decrypted text */
 // printf("Decrypted FINAL text is:\n");
  //printf("%s\n", decryptedtext6);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();



for (i =0; i < 10; ++i) {
  if (strcmp(encryptUsernames[i],"")==0) {
    strcpy(encryptUsernames[i], contactPerson);
    strcpy(encryptKey[i], masterKey);
  }
}

}

void removeKey(char *username) {
int i;
for (i =0; i < 10; ++i) {
  if (strcmp(encryptUsernames[i],username)==0) {
    strcpy(encryptUsernames[i], "");

  }
}
}

void handlePrivateMessage(char *username, char *data) {

int i;
//puts("STRAT");
//puts(username);
    for (i = 0; i < 10; ++i) {
      //puts(encryptUsernames[i]);
      //puts(encryptKey[i]);
      if (strcmp(username, encryptUsernames[i]) == 0 && strcmp(encryptUsernames[i],"") != 0) {
        break;
      }
    }

char deKey[8192];
strcpy(deKey, encryptKey[i]);



//printf("%s\n", data);



   // printf(KWHT "From %s:" KCYN " %s\n" RESET, username, data);





char modifiedMsg[8192];



int p, commaCount=0;
for (p = 0; p < strlen(data); ++p) {
  if (data[p] == ',') {
    ++commaCount;
  }
}




    char *pt;
    pt = strtok (data,",");
    //puts("LLLL");
    strcpy(modifiedMsg, "");
    i = 0;
    while (pt != NULL) {
      //puts("FF");
        int a = atoi(pt);
        //puts("II");
        modifiedMsg[i] = (char)a;
        //puts(pt);
        //puts("GG");
        pt = strtok (NULL, ",");
        //puts("HH");
/*        if (strcmp(pt,"")==0)
          break;*/
        ++i;
        if (commaCount == i)
          break;
    }

/*puts("OOOBBBBB");
printf("%d\n", commaCount);
puts(modifiedMsg);*/








     /* A 256 bit key */
    //puts(deKey);
  unsigned char *key = (unsigned char *)deKey;

  /* A 8192 bit IV */
  unsigned char *iv = (unsigned char *)"01234567890123456";

  /* Message to be encrypted */
  unsigned char *plaintext =
                (unsigned char *)"The quick brown fox jumps over the lazy dog";

  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext[8192];
  strcpy(ciphertext, modifiedMsg);

  int decryptedtext_len, ciphertext_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
   ciphertext_len =commaCount;
   /* encrypt (plaintext, strlen ((char *)plaintext), key, iv,
                            ciphertext);*/
  /* Do something useful with the ciphertext here */
 /* printf("Ciphertext is:\n");
  BIO_dump_fp (stdout, (const char *)modifiedMsg, commaCount);
  puts(modifiedMsg);*/

  /* Decrypt the ciphertext */
  decryptedtext_len = decrypt((unsigned const*)modifiedMsg, commaCount, key, iv,
    decryptedtext);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext[decryptedtext_len] = '\0';

  /* Show the decrypted text */
  /*printf("Decrypted text is:\n");
  printf("%s\n", decryptedtext);*/

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();
  

  printf(KWHT "From %s:" KCYN " %s\n" RESET, username, decryptedtext);

}


void handle_server_message(connection_info *connection)
{
  message msg;
  //Receive a reply from the server



  ssize_t recv_val = recv(connection->socket, &msg, sizeof(message), 0);
  if(recv_val < 0)
  {   printf("MML\n");
      perror("recv failed");
      exit(1);

  }
  else if(recv_val == 0)
  {
    close(connection->socket);
    puts("Server disconnected.");
    exit(0);
  }

/*if (msg.type != NULL)
  printf("BRODA %d\n", msg.type);*/

  switch(msg.type)
  {

    case CONNECT:
      printf(KYEL "%s has connected." RESET "\n", msg.username);
    break;

    case DISCONNECT:
      removeKey(msg.username);
      printf(KYEL "%s has disconnected." RESET "\n" , msg.username);
    break;

    case GET_USERS:
      printf(KYEL "%s" RESET "\n", msg.data);
    break;

    case SET_USERNAME:
      //TODO: implement: name changes in the future?
    break;

    case PUBLIC_MESSAGE:
      printf(KGRN "%s" RESET ": %s\n", msg.username, msg.data);
    break;

    case PRIVATE_MESSAGE:
      if(strcmp(strtok(msg.data, " "), "KDC3") == 0)
        kdcStep3(connection, strtok(NULL, ""));
      else
        handlePrivateMessage(msg.username, msg.data);
        
    break;

    case USERNAME_ERROR:
      printf(KWHT "%s:" KRED "\n" RESET, msg.data);
    break;

    case CREATE_GROUP:
      printf(KCYN " %s" RESET "\n",msg.data);
    break;

    case SUCCESS:
      login_success(connection, msg.data);
    break;

    case JOIN_GROUP:
      printf(KCYN " %s" RESET "\n",msg.data);
    break;

    case SEND_FILE:
      printf(KCYN " %s" RESET "\n",msg.data);
    break;

    case RECEIVE_FILE:
      receive_file(connection, msg.username, msg.data);
    break;

   /* case 20:
      printf(KCYN " %s" RESET "\n",msg.data);
      //kdcStep3(connection, msg.data);
    break;*/

    //case KDCSTEP5:
      //kdcStep5(connection, msg.data);
    //break;

    case TOO_FULL:
      fprintf(stderr, KRED "Server chatroom is too full to accept new clients." RESET "\n");
      exit(0);
    break;

    default:
      fprintf(stderr, KRED "Unknown message type received." RESET "\n");
    break;
  }
}

int main(int argc, char *argv[])
{

  // setting session keys as empty
  int i = 0;
  for (; i< 10; ++i) {
    strcpy(encryptUsernames[i],"");
  }



  connection_info connection;
  fd_set file_descriptors;

  if (argc != 3) {
    fprintf(stderr,"Usage: %s <IP> <port>\n", argv[0]);
    exit(1);
  }

  
  if (strcmp(argv[2],"5555")==0) {

        int sock;
    struct sockaddr_in server;
    char message[1000] , server_reply[2000];
     
    //Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket");
    }
    //puts("Socket created");
     
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons( 5555 );
 
    //Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("connect failed. Error");
        return 1;
    }
     
    puts("You are now on our registeration page.\n");


  printf("Enter username and Password separated by space: ");
        scanf("%s" , message);

        if( send(sock , message , strlen(message) , 0) < 0)
        {
            puts("Send failed");
            return 1;
        }

    memset(server_reply, 0, sizeof server_reply);
    if( recv(sock , server_reply , 2000 , 0) < 0)
        {
            puts("recv failed");
        }
    printf("%s", server_reply);   
    close(sock);
    return 0;

  } else {
    connect_to_server(&connection, argv[1], argv[2]);
    //strcpy(userPassword, argv[2]);
    
  //keep communicating with server
  while(true)
  {
    FD_ZERO(&file_descriptors);
    FD_SET(STDIN_FILENO, &file_descriptors);
    FD_SET(connection.socket, &file_descriptors);
    fflush(stdin);

    if(select(connection.socket+1, &file_descriptors, NULL, NULL, NULL) < 0)
    {
      perror("Select failed.");
      exit(1);
    }

    if(FD_ISSET(STDIN_FILENO, &file_descriptors))
    {
      handle_user_input(&connection);
    }

    if(FD_ISSET(connection.socket, &file_descriptors))
    {
      handle_server_message(&connection);
    }
  }
}
  close(connection.socket);
  return 0;
}



