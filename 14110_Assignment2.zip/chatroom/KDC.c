/*
    C socket server example
*/
 
#include<stdio.h>
#include <stdlib.h>
#include<string.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include <time.h>
#include "chatroom_utils.h"
#include "encrypt.h"
 #include <openssl/evp.h>

#define KEY_LEN      32
#define KEK_KEY_LEN  20
#define ITERATION     1 

int main(int argc , char *argv[])
{ 
    int socket_desc , client_sock , c , read_size, pid;
    struct sockaddr_in server , client;
    char client_message[2000], message_sent[2000], message_recieve[2000];
     
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");
     
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( 9999 );
     
    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
     
    //Listen
    listen(socket_desc , 3);
     
    while (1) {
        //Accept and incoming connection

        unsigned int timestamp = (unsigned)time(NULL);

        puts("Waiting for incoming connections...");
        c = sizeof(struct sockaddr_in);
     
        // accept connection from an incoming client
        client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
        if (client_sock < 0)
        {
            perror("accept failed");
            return 1;
        }

        /* Create child process */
        pid = fork();
      if (pid == 0) {
         /* This is the client process */
        close(socket_desc);
        puts("Connection accepted");
	
        char *username, *password;
        message msg;
        memset(message_recieve, 0, sizeof message_recieve);
        recv(client_sock , message_recieve , 2000 , 0);

/*        username = msg.username;
        password = msg.data;*/
    

        puts("message receive:");
        puts(message_recieve);

        FILE *file = fopen("registeredUsers.txt", "r");
        if (file == NULL)
        {
            printf("Error opening file!\n");
            exit(1);
        }
        int exist = 0;
        char uname[50], pass[50], pass1[50], pass2[50];
        int login = 0;
        strtok(message_recieve, " ");

        char sender[50];
        char receiver[50];
        strcpy(sender, strtok(NULL, " "));
        //puts(sender);
        strcpy(receiver, strtok(NULL, " "));
        //puts(receiver);
        
        while(fscanf(file, "%s %s\n", uname, pass) > 0) {
            //puts("Hello");
            if (strcmp(sender, uname)==0) {
                exist = 1;
                //puts("mid");
                strcpy(pass1, pass);
                //puts("midd");
            } 
             //puts("middle");
            if (strcmp(receiver, uname) ==0) {
                //puts("PUUUUUAAAAAA");
                //puts(pass);
                strcpy(pass2, pass);
            }
            //puts("BYE");
        }

 //puts("MMMMM");


 size_t j;
    unsigned char *out;
    char tem[100];
    strcpy(tem, pass1);
    strcat(tem, pass2);
    char pwd[100];
    strcpy(pwd, tem);
    unsigned char salt_value[] = {'s','a','l','t'};

    out = (unsigned char *) malloc(sizeof(unsigned char) * KEK_KEY_LEN);

   /* printf("pass: %s\n", pwd);
    printf("ITERATION: %u\n", ITERATION);
    printf("salt: "); for(i=0;i<sizeof(salt_value);i++) { printf("%02x", salt_value[i]); } printf("\n");
*/

    char modOut[8192];
    char temm[5];
    if( PKCS5_PBKDF2_HMAC_SHA1(pwd, strlen(pwd), salt_value, sizeof(salt_value), ITERATION, KEK_KEY_LEN, out) != 0 )
    {
        printf("out: "); for(j=0;j<3;j++) { 
            snprintf (temm, sizeof(temm), "%d",(int)out[j]);
            strcat(modOut, temm);
            printf("%02x", out[j]); } printf("\n");
    }
    else
    {
        fprintf(stderr, "PKCS5_PBKDF2_HMAC_SHA1 failed\n");
    }




//puts("HEY");
//puts(out);
out[strlen(out)]='\0';
//puts((char *)out);
//puts(modOut);



//puts("DRO");


char temp[500];
strcpy(temp, modOut);
strcat(temp, " ");
//puts("mml");
strcat(temp, sender);
//puts("bbb");
//puts(pass2);
strcat(temp, " ");

char timeTemp[50];
snprintf (timeTemp, sizeof(timeTemp), "%d",timestamp);

//puts(timeTemp);
strcat(temp, timeTemp);

  /* A 256 bit key */
  unsigned char *keyIn = (unsigned char *)pass2;
//puts("DRO");
  /* A 128 bit IV */
  unsigned char *ivIn = (unsigned char *)"01234567890123456";
//puts("DRO");
  /* Message to be encrypted */
  strtok(message_recieve, " ");
  //puts("DRO");
//puts(temp);
  unsigned char *plaintextIn =
                (unsigned char *)temp;
//puts("MRO");
//puts(plaintextIn);
 
   //strcat(plaintextIn, (char *)timestamp);
//puts("KRO");
//puts(plaintextIn);
  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertextIn[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtextIn[8192];

  int decryptedtextIn_len, ciphertextIn_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertextIn_len = encrypt (plaintextIn, strlen ((char *)plaintextIn), keyIn, ivIn,
                            ciphertextIn);

  /* Do something useful with the ciphertext here */
  printf("Ciphertext is:\n");
  BIO_dump_fp (stdout, (const char *)ciphertextIn, ciphertextIn_len);

  /* Decrypt the ciphertext */
  decryptedtextIn_len = decrypt(ciphertextIn, ciphertextIn_len, keyIn, ivIn,
    decryptedtextIn);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtextIn[decryptedtextIn_len] = '\0';

  /* Show the decrypted text */
  printf("Decrypted text is:\n");
  printf("%s\n", decryptedtextIn);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();
















char modifiedCiphertextIn[512];

strcpy(modifiedCiphertextIn, "");
int i;
char tek[10];
for (i = 0; i < ciphertextIn_len; ++i) {
    snprintf(tek, 10,"%d",(int)ciphertextIn[i]);
    strcat(modifiedCiphertextIn, tek);
    strcat(modifiedCiphertextIn, ",");
    printf("%s\n", modifiedCiphertextIn);
}










char temp2[500];
strcpy(temp2, modOut);
strcat(temp2, " ");
strcat(temp2, receiver);
strcat(temp2, " ");
strcat(temp2, timeTemp);
strcat(temp2, " ");
strcat(temp2, modifiedCiphertextIn);
//puts("DODOD");
//puts(temp2);


  /* A 256 bit key */
  unsigned char *key = (unsigned char *)pass1;

//puts(key);
  /* A 128 bit IV */
  unsigned char *iv = (unsigned char *)"01234567890123456";

  strtok(message_recieve, " ");
   strtok(NULL, " ");
  
  unsigned char *plaintext =
                (unsigned char *)temp2;


  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext[8192];

  /* Buffer for the decrypted text */
  unsigned char decryptedtext[8192];

  int decryptedtext_len, ciphertext_len;

  /* Initialise the library */
  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);

  /* Encrypt the plaintext */
  ciphertext_len = encrypt (temp2, strlen ((char *)plaintext), key, iv,
                            ciphertext);

  /* Do something useful with the ciphertext here */
  printf("Ciphertext is:\n");
  BIO_dump_fp (stdout, (const char *)ciphertext, ciphertext_len);

  /* Decrypt the ciphertext */
  decryptedtext_len = decrypt(ciphertext, ciphertext_len, key, iv,
    decryptedtext);

  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext[decryptedtext_len] = '\0';

  /* Show the decrypted text */
  printf("Decrypted text is:\n");
  printf("%s\n", decryptedtext);

  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();




char modifiedCiphertext[2048];

strcpy(modifiedCiphertext, "");
    
for (i = 0; i < ciphertext_len; ++i) {
    snprintf(tek, 10,"%d",(int)ciphertext[i]);
    strcat(modifiedCiphertext, tek);
    strcat(modifiedCiphertext, ",");
    //printf("%s\n", modifiedCiphertext);
}



strcat(modifiedCiphertext, " ");
snprintf(tek, 10,"%d",ciphertext_len);
printf("BABABABBABA %d\n", ciphertext_len);
strcat(modifiedCiphertext, tek);

//puts(modifiedCiphertext);



  /*  puts("KAKAKAKAKA");
    //puts (ciphertext_len);
    strcpy(message, ciphertext);
    puts(message);*/
            if( send(client_sock , modifiedCiphertext , strlen(modifiedCiphertext) , 0) < 0)
            {
                puts("Send failed");
                return 1;
            }
        if(read_size == 0)
        {
            puts("Client disconnected");
            fflush(stdout);
        }
        else if(read_size == -1)
        {
         perror("recv failed");
        }
        exit(0);
    } else {
        close(client_sock);
    }
    }
     
    return 0;
}